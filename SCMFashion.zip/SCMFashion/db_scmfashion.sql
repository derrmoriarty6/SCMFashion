-- ============================================
-- DATABASE: db_scmfashion
-- Sistem Informasi Pengolahan Data Pelanggan
-- Toko Mode Fashion (SCMFashion)
-- ============================================

CREATE DATABASE IF NOT EXISTS db_scmfashion;
USE db_scmfashion;

-- ============================================
-- TABEL USER (untuk Login)
-- ============================================
CREATE TABLE IF NOT EXISTS tbluser (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(50) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    level VARCHAR(20) NOT NULL DEFAULT 'Operator'
) ENGINE=InnoDB;

INSERT INTO tbluser (username, password, nama_lengkap, level) VALUES
('admin', 'admin123', 'Administrator', 'Admin'),
('operator', 'operator123', 'Operator Toko', 'Operator');

-- ============================================
-- TABEL PELANGGAN (mapping dari tblmahasiswa)
-- ============================================
CREATE TABLE IF NOT EXISTS tblpelanggan (
    id_pelanggan VARCHAR(10) PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    tempat_lahir VARCHAR(50),
    tgl_lahir DATE,
    usia VARCHAR(30),
    jenis_kelamin VARCHAR(15),
    membership VARCHAR(20),
    alamat TEXT,
    telp VARCHAR(15)
) ENGINE=InnoDB;

INSERT INTO tblpelanggan VALUES
('PLG001', 'Siti Rahma', 'Jakarta', '1995-03-15', '31 tahun, 2 Bulan', 'Perempuan', 'Gold', 'Jl. Merdeka No.10, Jakarta', '081234567890'),
('PLG002', 'Budi Santoso', 'Bandung', '1990-07-20', '35 tahun, 10 Bulan', 'Laki-Laki', 'Silver', 'Jl. Sudirman No.5, Bandung', '082345678901'),
('PLG003', 'Dewi Lestari', 'Surabaya', '1998-11-05', '27 tahun, 6 Bulan', 'Perempuan', 'Bronze', 'Jl. Ahmad Yani No.8, Surabaya', '083456789012');

-- ============================================
-- TABEL PRODUK (mapping dari tbldosen)
-- ============================================
CREATE TABLE IF NOT EXISTS tblproduk (
    kd_produk VARCHAR(10) PRIMARY KEY,
    nm_produk VARCHAR(100) NOT NULL,
    harga VARCHAR(20),
    stok VARCHAR(10)
) ENGINE=InnoDB;

INSERT INTO tblproduk VALUES
('PRD001', 'Kemeja Batik Premium', '250000', '50'),
('PRD002', 'Dress Casual Wanita', '180000', '30'),
('PRD003', 'Celana Jeans Slim Fit', '200000', '40'),
('PRD004', 'Jaket Hoodie Unisex', '150000', '25'),
('PRD005', 'Rok Mini Plisket', '120000', '35');

-- ============================================
-- TABEL KATEGORI (mapping dari tblmatakuliah)
-- ============================================
CREATE TABLE IF NOT EXISTS tblkategori (
    kd_kategori VARCHAR(10) PRIMARY KEY,
    nm_kategori VARCHAR(100) NOT NULL,
    deskripsi VARCHAR(200)
) ENGINE=InnoDB;

INSERT INTO tblkategori VALUES
('KAT001', 'Atasan', 'Kemeja, Blouse, Kaos, T-Shirt'),
('KAT002', 'Bawahan', 'Celana, Rok, Kulot'),
('KAT003', 'Outerwear', 'Jaket, Blazer, Cardigan'),
('KAT004', 'Dress', 'Dress Casual, Dress Formal'),
('KAT005', 'Aksesoris', 'Topi, Tas, Ikat Pinggang');

-- ============================================
-- TABEL TRANSAKSI (mapping dari tblnilai)
-- ============================================
CREATE TABLE IF NOT EXISTS tbltransaksi (
    id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
    tgl_transaksi VARCHAR(20),
    metode_bayar VARCHAR(20),
    id_pelanggan VARCHAR(10),
    kd_produk VARCHAR(10),
    kd_kategori VARCHAR(10),
    qty INT,
    harga_satuan DOUBLE,
    diskon DOUBLE,
    total_harga DOUBLE,
    status VARCHAR(20),
    FOREIGN KEY (id_pelanggan) REFERENCES tblpelanggan(id_pelanggan),
    FOREIGN KEY (kd_produk) REFERENCES tblproduk(kd_produk),
    FOREIGN KEY (kd_kategori) REFERENCES tblkategori(kd_kategori)
) ENGINE=InnoDB;

-- ============================================
-- VIEW QUERYTRANSAKSI (mapping dari querynilai)
-- ============================================
CREATE OR REPLACE VIEW querytransaksi AS
SELECT 
    t.id_transaksi,
    t.tgl_transaksi,
    t.metode_bayar,
    t.id_pelanggan,
    p.nama AS nama_pelanggan,
    p.telp,
    p.membership,
    t.kd_produk,
    pr.nm_produk,
    pr.harga AS harga_produk,
    pr.stok,
    t.kd_kategori,
    k.nm_kategori,
    k.deskripsi,
    t.qty,
    t.harga_satuan,
    t.diskon,
    t.total_harga,
    t.status
FROM tbltransaksi t
LEFT JOIN tblpelanggan p ON t.id_pelanggan = p.id_pelanggan
LEFT JOIN tblproduk pr ON t.kd_produk = pr.kd_produk
LEFT JOIN tblkategori k ON t.kd_kategori = k.kd_kategori;
