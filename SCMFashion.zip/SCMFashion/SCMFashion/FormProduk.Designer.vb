<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormProduk
    Inherits System.Windows.Forms.Form
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then components.Dispose()
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub
    Private components As System.ComponentModel.IContainer
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.txtKdProduk = New System.Windows.Forms.TextBox()
        Me.txtNamaProduk = New System.Windows.Forms.TextBox()
        Me.txtHarga = New System.Windows.Forms.TextBox()
        Me.txtStok = New System.Windows.Forms.TextBox()
        Me.btnCariData = New System.Windows.Forms.Button()
        Me.txtCariData = New System.Windows.Forms.TextBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        'Label1
        Me.Label1.AutoSize = True : Me.Label1.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D : Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold) : Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label1.Location = New System.Drawing.Point(227, 24) : Me.Label1.Name = "Label1" : Me.Label1.Size = New System.Drawing.Size(290, 26) : Me.Label1.TabIndex = 1 : Me.Label1.Text = "FORM INPUT DATA PRODUK"
        'Label2
        Me.Label2.AutoSize = True : Me.Label2.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label2.Location = New System.Drawing.Point(31, 79) : Me.Label2.Name = "Label2" : Me.Label2.Size = New System.Drawing.Size(90, 18) : Me.Label2.TabIndex = 2 : Me.Label2.Text = "Kode Produk"
        'Label3
        Me.Label3.AutoSize = True : Me.Label3.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label3.Location = New System.Drawing.Point(31, 112) : Me.Label3.Name = "Label3" : Me.Label3.Size = New System.Drawing.Size(100, 18) : Me.Label3.TabIndex = 3 : Me.Label3.Text = "Nama Produk"
        'Label4
        Me.Label4.AutoSize = True : Me.Label4.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label4.Location = New System.Drawing.Point(31, 144) : Me.Label4.Name = "Label4" : Me.Label4.Size = New System.Drawing.Size(50, 18) : Me.Label4.TabIndex = 4 : Me.Label4.Text = "Harga"
        'Label5
        Me.Label5.AutoSize = True : Me.Label5.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label5.Location = New System.Drawing.Point(31, 177) : Me.Label5.Name = "Label5" : Me.Label5.Size = New System.Drawing.Size(38, 18) : Me.Label5.TabIndex = 5 : Me.Label5.Text = "Stok"
        'Label6 Pencarian
        Me.Label6.AutoSize = True : Me.Label6.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label6.Location = New System.Drawing.Point(27, 240) : Me.Label6.Name = "Label6" : Me.Label6.Size = New System.Drawing.Size(74, 18) : Me.Label6.TabIndex = 6 : Me.Label6.Text = "Pencarian"
        'Buttons
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnExit.Location = New System.Drawing.Point(362, 208) : Me.btnExit.Name = "btnExit" : Me.btnExit.Size = New System.Drawing.Size(79, 29) : Me.btnExit.Text = "EXIT" : Me.btnExit.UseVisualStyleBackColor = False : Me.btnExit.TabIndex = 33
        Me.btnDelete.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnDelete.Location = New System.Drawing.Point(280, 208) : Me.btnDelete.Name = "btnDelete" : Me.btnDelete.Size = New System.Drawing.Size(79, 29) : Me.btnDelete.Text = "DELETE" : Me.btnDelete.UseVisualStyleBackColor = False : Me.btnDelete.TabIndex = 32
        Me.btnEdit.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnEdit.Location = New System.Drawing.Point(197, 208) : Me.btnEdit.Name = "btnEdit" : Me.btnEdit.Size = New System.Drawing.Size(79, 29) : Me.btnEdit.Text = "EDIT" : Me.btnEdit.UseVisualStyleBackColor = False : Me.btnEdit.TabIndex = 31
        Me.btnSave.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnSave.Location = New System.Drawing.Point(114, 208) : Me.btnSave.Name = "btnSave" : Me.btnSave.Size = New System.Drawing.Size(79, 29) : Me.btnSave.Text = "SAVE" : Me.btnSave.UseVisualStyleBackColor = False : Me.btnSave.TabIndex = 30
        Me.btnRefresh.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnRefresh.Location = New System.Drawing.Point(31, 208) : Me.btnRefresh.Name = "btnRefresh" : Me.btnRefresh.Size = New System.Drawing.Size(79, 29) : Me.btnRefresh.Text = "REFRESH" : Me.btnRefresh.UseVisualStyleBackColor = False : Me.btnRefresh.TabIndex = 29
        'TextBoxes
        Me.txtKdProduk.Location = New System.Drawing.Point(148, 79) : Me.txtKdProduk.Name = "txtKdProduk" : Me.txtKdProduk.Size = New System.Drawing.Size(87, 20) : Me.txtKdProduk.TabIndex = 34
        Me.txtNamaProduk.Location = New System.Drawing.Point(148, 112) : Me.txtNamaProduk.Name = "txtNamaProduk" : Me.txtNamaProduk.Size = New System.Drawing.Size(200, 20) : Me.txtNamaProduk.TabIndex = 35
        Me.txtHarga.Location = New System.Drawing.Point(148, 145) : Me.txtHarga.Name = "txtHarga" : Me.txtHarga.Size = New System.Drawing.Size(143, 20) : Me.txtHarga.TabIndex = 36
        Me.txtStok.Location = New System.Drawing.Point(148, 177) : Me.txtStok.Name = "txtStok" : Me.txtStok.Size = New System.Drawing.Size(80, 20) : Me.txtStok.TabIndex = 37
        'Search
        Me.btnCariData.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnCariData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnCariData.Location = New System.Drawing.Point(615, 242) : Me.btnCariData.Name = "btnCariData" : Me.btnCariData.Size = New System.Drawing.Size(92, 19) : Me.btnCariData.Text = "CARI DATA" : Me.btnCariData.UseVisualStyleBackColor = False : Me.btnCariData.TabIndex = 38
        Me.txtCariData.Location = New System.Drawing.Point(102, 241) : Me.txtCariData.Name = "txtCariData" : Me.txtCariData.Size = New System.Drawing.Size(509, 20) : Me.txtCariData.TabIndex = 39
        'ListView
        Me.ListView1.FullRowSelect = True : Me.ListView1.GridLines = True : Me.ListView1.Location = New System.Drawing.Point(30, 265) : Me.ListView1.MultiSelect = False : Me.ListView1.Name = "ListView1" : Me.ListView1.Size = New System.Drawing.Size(677, 169) : Me.ListView1.UseCompatibleStateImageBehavior = False : Me.ListView1.View = System.Windows.Forms.View.Details : Me.ListView1.TabIndex = 40
        'Panel1
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel1.Controls.Add(Me.ListView1) : Me.Panel1.Controls.Add(Me.txtCariData) : Me.Panel1.Controls.Add(Me.Label1) : Me.Panel1.Controls.Add(Me.btnCariData) : Me.Panel1.Controls.Add(Me.Label2) : Me.Panel1.Controls.Add(Me.txtStok) : Me.Panel1.Controls.Add(Me.Label3) : Me.Panel1.Controls.Add(Me.txtHarga) : Me.Panel1.Controls.Add(Me.Label4) : Me.Panel1.Controls.Add(Me.txtNamaProduk) : Me.Panel1.Controls.Add(Me.Label5) : Me.Panel1.Controls.Add(Me.txtKdProduk) : Me.Panel1.Controls.Add(Me.Label6) : Me.Panel1.Controls.Add(Me.btnExit) : Me.Panel1.Controls.Add(Me.btnRefresh) : Me.Panel1.Controls.Add(Me.btnDelete) : Me.Panel1.Controls.Add(Me.btnSave) : Me.Panel1.Controls.Add(Me.btnEdit)
        Me.Panel1.Location = New System.Drawing.Point(0, 0) : Me.Panel1.Name = "Panel1" : Me.Panel1.Size = New System.Drawing.Size(774, 448) : Me.Panel1.TabIndex = 41
        'FormProduk
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(728, 445)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FormProduk" : Me.Text = "Form Input Data Produk"
        Me.Panel1.ResumeLayout(False) : Me.Panel1.PerformLayout() : Me.ResumeLayout(False)
    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents txtKdProduk As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaProduk As System.Windows.Forms.TextBox
    Friend WithEvents txtHarga As System.Windows.Forms.TextBox
    Friend WithEvents txtStok As System.Windows.Forms.TextBox
    Friend WithEvents btnCariData As System.Windows.Forms.Button
    Friend WithEvents txtCariData As System.Windows.Forms.TextBox
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
