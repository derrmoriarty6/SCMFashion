Imports MySql.Data.MySqlClient
Public Class FormCariPelanggan
    Private Sub Posisilist()
        With ListView1.Columns
            .Add("ID Pelanggan", 80) : .Add("Nama", 120) : .Add("Tempat Lahir", 100) : .Add("Tanggal Lahir", 90) : .Add("Usia", 100) : .Add("Jenis Kelamin", 90) : .Add("Membership", 80) : .Add("Alamat", 150) : .Add("Telp/HP", 100)
        End With
    End Sub
    Private Sub Isilist()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblpelanggan ORDER BY id_pelanggan"
            daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData) : ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub
    Private Sub caridatapelanggan()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblpelanggan WHERE id_pelanggan like '%" & Trim(txtCariData.Text) & "%' or nama like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData) : ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub
    Private Sub AmbilDataDariListview()
        With ListView1.SelectedItems
            Try
                FormTransaksi.txtIdPelanggan.Text = .Item(0).SubItems(0).Text
                FormTransaksi.txtNamaPelanggan.Text = .Item(0).SubItems(1).Text
            Catch ex As Exception
            End Try
        End With
    End Sub
    Private Sub FormCariPelanggan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksiKeDataBase() : Posisilist() : Isilist()
    End Sub
    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatapelanggan()
    End Sub
    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatapelanggan()
    End Sub
    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview() : Me.Close()
    End Sub
End Class
