Imports MySql.Data.MySqlClient
Public Class FormProduk

    Private Sub caridataproduk()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblproduk WHERE kd_produk like '%" & Trim(txtCariData.Text) & "%' or nm_produk like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub AmbilDataDariListview()
        With ListView1.SelectedItems
            Try
                txtKdProduk.Text = .Item(0).SubItems(0).Text
                txtNamaProduk.Text = .Item(0).SubItems(1).Text
                txtHarga.Text = .Item(0).SubItems(2).Text
                txtStok.Text = .Item(0).SubItems(3).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub Posisilist()
        With ListView1.Columns
            .Add("Kode Produk", 100)
            .Add("Nama Produk", 200)
            .Add("Harga", 120)
            .Add("Stok", 80)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblproduk ORDER BY kd_produk"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub bersih()
        txtKdProduk.Text = "" : txtNamaProduk.Text = "" : txtHarga.Text = "" : txtStok.Text = ""
    End Sub

    Private Sub FormProduk_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksiKeDataBase() : Posisilist() : Isilist()
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        bersih() : Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKdProduk.Text = "" Or txtNamaProduk.Text = "" Or txtHarga.Text = "" Or txtStok.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKdProduk.Focus()
            Else
                query = "INSERT INTO tblproduk VALUES('" & txtKdProduk.Text & "','" & txtNamaProduk.Text & "','" & txtHarga.Text & "','" & txtStok.Text & "')"
                daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                MsgBox("Data berhasil disimpan!", MsgBoxStyle.Information, "SAVE")
                txtKdProduk.Focus() : Isilist() : bersih()
            End If
        Catch ex As Exception
            MsgBox("Kode Produk ini sudah ada!", MsgBoxStyle.Exclamation, "Error") : txtKdProduk.Focus()
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview()
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridataproduk()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridataproduk()
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If txtKdProduk.Text = "" Or txtNamaProduk.Text = "" Or txtHarga.Text = "" Or txtStok.Text = "" Then
                MsgBox("Silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKdProduk.Focus()
            Else
                query = "UPDATE tblproduk SET nm_produk='" & txtNamaProduk.Text & "',harga='" & txtHarga.Text & "', stok='" & txtStok.Text & "' WHERE kd_produk='" & txtKdProduk.Text & "' "
                daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                Isilist() : bersih() : txtKdProduk.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            Dim A As String
            A = MsgBox("Benar data akan di delete...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case A
                Case vbCancel : txtKdProduk.Focus() : Exit Sub
                Case vbOK
                    If txtKdProduk.Text = "" Then
                        MsgBox("Input Kode Produk Yang Akan Di Hapus", MsgBoxStyle.Critical, "Data Kosong")
                        txtKdProduk.Focus()
                    Else
                        query = "DELETE from tblproduk WHERE kd_produk='" & txtKdProduk.Text & "'"
                        daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                        Isilist() : bersih()
                        MsgBox("Data Berhasil Di Delete", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Hapus data")
        End Try
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
