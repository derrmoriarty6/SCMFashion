Imports MySql.Data.MySqlClient
Public Class FormTransaksi
    Dim hargaSatuan As Double
    Dim totalHarga As Double
    Dim diskonPersen As Double
    Dim statusBayar, idtransaksi As String

    Private Sub AmbilDataDariListview()
        With ListView1.SelectedItems
            Try
                idtransaksi = .Item(0).SubItems(0).Text
                cboTahun.Text = .Item(0).SubItems(1).Text
                CboMetodeBayar.Text = .Item(0).SubItems(2).Text
                txtIdPelanggan.Text = .Item(0).SubItems(3).Text
                txtNamaPelanggan.Text = .Item(0).SubItems(4).Text
                txtKdProduk.Text = .Item(0).SubItems(5).Text
                txtNamaProduk.Text = .Item(0).SubItems(6).Text
                txtKdKategori.Text = .Item(0).SubItems(7).Text
                txtNamaKategori.Text = .Item(0).SubItems(8).Text
                txtQty.Text = .Item(0).SubItems(9).Text
                txtHargaSatuan.Text = .Item(0).SubItems(10).Text
                txtDiskon.Text = .Item(0).SubItems(11).Text
                txtTotalHarga.Text = .Item(0).SubItems(12).Text
                txtStatus.Text = .Item(0).SubItems(13).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub posisilist()
        ListView1.Columns.Clear()
        ListView1.View = View.Details
        ListView1.FullRowSelect = True
        ListView1.GridLines = True
        With ListView1.Columns
            .Add("ID", 40)
            .Add("Tgl Transaksi", 90)
            .Add("Metode Bayar", 80)
            .Add("ID Pelanggan", 80)
            .Add("Nama Pelanggan", 120)
            .Add("Kd Produk", 70)
            .Add("Nama Produk", 120)
            .Add("Kd Kategori", 70)
            .Add("Nama Kategori", 100)
            .Add("Qty", 40)
            .Add("Harga Satuan", 80)
            .Add("Diskon(%)", 60)
            .Add("Total Harga", 80)
            .Add("Status", 80)
        End With
    End Sub

    Private Sub isilist()
        Dim a As Integer
        Try
            query = "Select * From querytransaksi Order by id_transaksi"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(11))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(12))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(14))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(15))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(16))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(17))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(18))
                End With
            Next
        Catch ex As Exception
            MsgBox("Gagal menampilkan data: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub prosestransaksi()
        Try
            Dim qty As Integer = CInt(txtQty.Text)
            hargaSatuan = CDbl(txtHargaSatuan.Text)
            diskonPersen = CDbl(txtDiskon.Text)
            Dim subtotal As Double = qty * hargaSatuan
            Dim potongan As Double = subtotal * (diskonPersen / 100)
            totalHarga = subtotal - potongan
            If totalHarga >= 500000 Then
                statusBayar = "Premium"
            ElseIf totalHarga >= 200000 Then
                statusBayar = "Lunas"
            Else
                statusBayar = "Lunas"
            End If
            txtTotalHarga.Text = totalHarga.ToString()
            txtStatus.Text = statusBayar
        Catch ex As Exception
            MsgBox("Masukkan angka yang valid!", MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub BtnCariPelanggan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCariPelanggan.Click
        FormCariPelanggan.Show()
    End Sub

    Private Sub BtnCariProduk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCariProduk.Click
        FormCariProduk.Show()
    End Sub

    Private Sub btnCariKategori_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariKategori.Click
        FormCariKategori.Show()
    End Sub

    Private Sub BtnProses_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnProses.Click
        prosestransaksi()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If cboTahun.Text = "" Or CboMetodeBayar.Text = "" Or txtIdPelanggan.Text = "" Or txtKdProduk.Text = "" Or txtKdKategori.Text = "" Or txtQty.Text = "" Or txtHargaSatuan.Text = "" Or txtTotalHarga.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
            Else
                Call koneksiKeDataBase()
                query = "insert into tbltransaksi(tgl_transaksi,metode_bayar,id_pelanggan,kd_produk,kd_kategori,qty,harga_satuan,diskon,total_harga,status) values ('" & cboTahun.Text & "','" & CboMetodeBayar.Text & "','" & txtIdPelanggan.Text & "','" & txtKdProduk.Text & "','" & txtKdKategori.Text & "','" & txtQty.Text & "','" & txtHargaSatuan.Text & "','" & txtDiskon.Text & "','" & txtTotalHarga.Text & "','" & txtStatus.Text & "')"
                daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                MsgBox("Data berhasil disimpan!", MsgBoxStyle.Information, "SAVE")
                cboTahun.Focus() : isilist() : bersihkandata()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub FormTransaksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksiKeDataBase() : posisilist() : isilist()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview()
    End Sub

    Private Sub bersihkandata()
        cboTahun.Text = "" : CboMetodeBayar.Text = "" : txtIdPelanggan.Text = "" : txtNamaPelanggan.Text = ""
        txtKdProduk.Text = "" : txtNamaProduk.Text = "" : txtKdKategori.Text = "" : txtNamaKategori.Text = ""
        txtQty.Text = "" : txtHargaSatuan.Text = "" : txtDiskon.Text = "" : txtTotalHarga.Text = "" : txtStatus.Text = ""
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        bersihkandata()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If cboTahun.Text = "" Or txtIdPelanggan.Text = "" Or txtKdProduk.Text = "" Then
                MsgBox("Lengkapi data yang akan diedit", MsgBoxStyle.Critical, "Pesan Kosong")
            Else
                query = "Update tbltransaksi set tgl_transaksi='" & cboTahun.Text & "',metode_bayar='" & CboMetodeBayar.Text & "',id_pelanggan='" & txtIdPelanggan.Text & "',kd_produk='" & txtKdProduk.Text & "',kd_kategori='" & txtKdKategori.Text & "',qty='" & txtQty.Text & "',harga_satuan='" & txtHargaSatuan.Text & "',diskon='" & txtDiskon.Text & "',total_harga='" & txtTotalHarga.Text & "',status='" & txtStatus.Text & "' where id_transaksi='" & idtransaksi & "'"
                daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                MsgBox("Data berhasil di edit!", MsgBoxStyle.Information, "Edit")
                isilist() : bersihkandata() : cboTahun.Focus()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            Dim A As String
            A = MsgBox("Benar data akan di delete...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case A
                Case vbCancel : cboTahun.Focus() : Exit Sub
                Case vbOK
                    query = "DELETE from tbltransaksi WHERE id_transaksi='" & idtransaksi & "'"
                    daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                    isilist() : bersihkandata()
                    MsgBox("Data Berhasil Di Delete", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub
End Class
