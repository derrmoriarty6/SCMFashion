Imports MySql.Data.MySqlClient
Public Class FormLogin

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Try
            If txtUsername.Text = "" Or txtPassword.Text = "" Then
                MsgBox("Silahkan isi Username dan Password!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtUsername.Focus()
            Else
                Call koneksiKeDataBase()
                cmd = New MySqlCommand("SELECT * FROM tbluser WHERE username='" & txtUsername.Text & "' AND password='" & txtPassword.Text & "'", conn)
                RD = cmd.ExecuteReader
                RD.Read()
                If RD.HasRows = True Then
                    MsgBox("Login Berhasil! Selamat Datang " & RD("nama_lengkap").ToString(), MsgBoxStyle.Information, "Login Sukses")
                    Me.Hide()
                    F_MenuUtama.Show()
                Else
                    MsgBox("Username atau Password salah!", MsgBoxStyle.Critical, "Login Gagal")
                    txtUsername.Focus()
                    txtUsername.Text = ""
                    txtPassword.Text = ""
                End If
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        End
    End Sub

    Private Sub FormLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call koneksiKeDataBase()
        txtUsername.Focus()
    End Sub

    Private Sub txtPassword_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtPassword.KeyDown
        If e.KeyCode = Keys.Enter Then
            btnLogin_Click(sender, e)
        End If
    End Sub
End Class
