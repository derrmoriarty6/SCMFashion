<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormKategori
    Inherits System.Windows.Forms.Form
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then components.Dispose()
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub
    Private components As System.ComponentModel.IContainer
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.txtKdKategori = New System.Windows.Forms.TextBox()
        Me.txtNamaKategori = New System.Windows.Forms.TextBox()
        Me.txtDeskripsi = New System.Windows.Forms.TextBox()
        Me.btnCariData = New System.Windows.Forms.Button()
        Me.txtCariData = New System.Windows.Forms.TextBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout() : Me.SuspendLayout()
        'Label1
        Me.Label1.AutoSize = True : Me.Label1.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D : Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold) : Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label1.Location = New System.Drawing.Point(200, 24) : Me.Label1.Name = "Label1" : Me.Label1.Size = New System.Drawing.Size(320, 26) : Me.Label1.TabIndex = 1 : Me.Label1.Text = "FORM INPUT DATA KATEGORI"
        'Label2
        Me.Label2.AutoSize = True : Me.Label2.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label2.Location = New System.Drawing.Point(31, 79) : Me.Label2.Name = "Label2" : Me.Label2.Size = New System.Drawing.Size(105, 18) : Me.Label2.TabIndex = 2 : Me.Label2.Text = "Kode Kategori"
        'Label3
        Me.Label3.AutoSize = True : Me.Label3.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label3.Location = New System.Drawing.Point(31, 112) : Me.Label3.Name = "Label3" : Me.Label3.Size = New System.Drawing.Size(115, 18) : Me.Label3.TabIndex = 3 : Me.Label3.Text = "Nama Kategori"
        'Label4
        Me.Label4.AutoSize = True : Me.Label4.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label4.Location = New System.Drawing.Point(31, 144) : Me.Label4.Name = "Label4" : Me.Label4.Size = New System.Drawing.Size(75, 18) : Me.Label4.TabIndex = 4 : Me.Label4.Text = "Deskripsi"
        'Label5
        Me.Label5.AutoSize = True : Me.Label5.BackColor = System.Drawing.SystemColors.ControlDarkDark : Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label5.Location = New System.Drawing.Point(27, 210) : Me.Label5.Name = "Label5" : Me.Label5.Size = New System.Drawing.Size(74, 18) : Me.Label5.TabIndex = 5 : Me.Label5.Text = "Pencarian"
        'Buttons
        Me.btnRefresh.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnRefresh.Location = New System.Drawing.Point(31, 177) : Me.btnRefresh.Name = "btnRefresh" : Me.btnRefresh.Size = New System.Drawing.Size(79, 29) : Me.btnRefresh.Text = "REFRESH" : Me.btnRefresh.UseVisualStyleBackColor = False : Me.btnRefresh.TabIndex = 29
        Me.btnSave.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnSave.Location = New System.Drawing.Point(114, 177) : Me.btnSave.Name = "btnSave" : Me.btnSave.Size = New System.Drawing.Size(79, 29) : Me.btnSave.Text = "SAVE" : Me.btnSave.UseVisualStyleBackColor = False : Me.btnSave.TabIndex = 30
        Me.btnEdit.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnEdit.Location = New System.Drawing.Point(197, 177) : Me.btnEdit.Name = "btnEdit" : Me.btnEdit.Size = New System.Drawing.Size(79, 29) : Me.btnEdit.Text = "EDIT" : Me.btnEdit.UseVisualStyleBackColor = False : Me.btnEdit.TabIndex = 31
        Me.btnDelete.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnDelete.Location = New System.Drawing.Point(280, 177) : Me.btnDelete.Name = "btnDelete" : Me.btnDelete.Size = New System.Drawing.Size(79, 29) : Me.btnDelete.Text = "DELETE" : Me.btnDelete.UseVisualStyleBackColor = False : Me.btnDelete.TabIndex = 32
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnExit.Location = New System.Drawing.Point(362, 177) : Me.btnExit.Name = "btnExit" : Me.btnExit.Size = New System.Drawing.Size(79, 29) : Me.btnExit.Text = "EXIT" : Me.btnExit.UseVisualStyleBackColor = False : Me.btnExit.TabIndex = 33
        'TextBoxes
        Me.txtKdKategori.Location = New System.Drawing.Point(160, 79) : Me.txtKdKategori.Name = "txtKdKategori" : Me.txtKdKategori.Size = New System.Drawing.Size(87, 20) : Me.txtKdKategori.TabIndex = 34
        Me.txtNamaKategori.Location = New System.Drawing.Point(160, 112) : Me.txtNamaKategori.Name = "txtNamaKategori" : Me.txtNamaKategori.Size = New System.Drawing.Size(200, 20) : Me.txtNamaKategori.TabIndex = 35
        Me.txtDeskripsi.Location = New System.Drawing.Point(160, 145) : Me.txtDeskripsi.Name = "txtDeskripsi" : Me.txtDeskripsi.Size = New System.Drawing.Size(300, 20) : Me.txtDeskripsi.TabIndex = 36
        'Search
        Me.btnCariData.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnCariData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnCariData.Location = New System.Drawing.Point(615, 212) : Me.btnCariData.Name = "btnCariData" : Me.btnCariData.Size = New System.Drawing.Size(92, 19) : Me.btnCariData.Text = "CARI DATA" : Me.btnCariData.UseVisualStyleBackColor = False : Me.btnCariData.TabIndex = 38
        Me.txtCariData.Location = New System.Drawing.Point(102, 211) : Me.txtCariData.Name = "txtCariData" : Me.txtCariData.Size = New System.Drawing.Size(509, 20) : Me.txtCariData.TabIndex = 39
        'ListView
        Me.ListView1.FullRowSelect = True : Me.ListView1.GridLines = True : Me.ListView1.Location = New System.Drawing.Point(30, 235) : Me.ListView1.MultiSelect = False : Me.ListView1.Name = "ListView1" : Me.ListView1.Size = New System.Drawing.Size(677, 169) : Me.ListView1.UseCompatibleStateImageBehavior = False : Me.ListView1.View = System.Windows.Forms.View.Details : Me.ListView1.TabIndex = 40
        'Panel1
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel1.Controls.Add(Me.ListView1) : Me.Panel1.Controls.Add(Me.txtCariData) : Me.Panel1.Controls.Add(Me.Label1) : Me.Panel1.Controls.Add(Me.btnCariData) : Me.Panel1.Controls.Add(Me.Label2) : Me.Panel1.Controls.Add(Me.txtDeskripsi) : Me.Panel1.Controls.Add(Me.Label3) : Me.Panel1.Controls.Add(Me.txtNamaKategori) : Me.Panel1.Controls.Add(Me.Label4) : Me.Panel1.Controls.Add(Me.txtKdKategori) : Me.Panel1.Controls.Add(Me.Label5) : Me.Panel1.Controls.Add(Me.btnExit) : Me.Panel1.Controls.Add(Me.btnRefresh) : Me.Panel1.Controls.Add(Me.btnDelete) : Me.Panel1.Controls.Add(Me.btnSave) : Me.Panel1.Controls.Add(Me.btnEdit)
        Me.Panel1.Location = New System.Drawing.Point(0, 0) : Me.Panel1.Name = "Panel1" : Me.Panel1.Size = New System.Drawing.Size(774, 420) : Me.Panel1.TabIndex = 41
        'FormKategori
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(728, 415)
        Me.Controls.Add(Me.Panel1) : Me.Name = "FormKategori" : Me.Text = "Form Input Data Kategori"
        Me.Panel1.ResumeLayout(False) : Me.Panel1.PerformLayout() : Me.ResumeLayout(False)
    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents txtKdKategori As System.Windows.Forms.TextBox
    Friend WithEvents txtNamaKategori As System.Windows.Forms.TextBox
    Friend WithEvents txtDeskripsi As System.Windows.Forms.TextBox
    Friend WithEvents btnCariData As System.Windows.Forms.Button
    Friend WithEvents txtCariData As System.Windows.Forms.TextBox
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
