<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormCariProduk
    Inherits System.Windows.Forms.Form
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then components.Dispose()
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub
    Private components As System.ComponentModel.IContainer
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtCariData = New System.Windows.Forms.TextBox()
        Me.btnCariData = New System.Windows.Forms.Button()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Panel1.SuspendLayout() : Me.SuspendLayout()
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel1.Controls.Add(Me.Label1) : Me.Panel1.Controls.Add(Me.Label2) : Me.Panel1.Controls.Add(Me.txtCariData) : Me.Panel1.Controls.Add(Me.btnCariData) : Me.Panel1.Controls.Add(Me.ListView1)
        Me.Panel1.Location = New System.Drawing.Point(0, 0) : Me.Panel1.Name = "Panel1" : Me.Panel1.Size = New System.Drawing.Size(600, 350) : Me.Panel1.TabIndex = 0
        Me.Label1.AutoSize = True : Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D : Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold) : Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label1.Location = New System.Drawing.Point(150, 15) : Me.Label1.Name = "Label1" : Me.Label1.Size = New System.Drawing.Size(280, 26) : Me.Label1.Text = "CARI DATA PRODUK"
        Me.Label2.AutoSize = True : Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!) : Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.Label2.Location = New System.Drawing.Point(20, 55) : Me.Label2.Name = "Label2" : Me.Label2.Text = "Pencarian"
        Me.txtCariData.Location = New System.Drawing.Point(100, 55) : Me.txtCariData.Name = "txtCariData" : Me.txtCariData.Size = New System.Drawing.Size(350, 20) : Me.txtCariData.TabIndex = 1
        Me.btnCariData.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnCariData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnCariData.Location = New System.Drawing.Point(460, 55) : Me.btnCariData.Name = "btnCariData" : Me.btnCariData.Size = New System.Drawing.Size(92, 20) : Me.btnCariData.Text = "CARI DATA" : Me.btnCariData.UseVisualStyleBackColor = False
        Me.ListView1.FullRowSelect = True : Me.ListView1.GridLines = True : Me.ListView1.Location = New System.Drawing.Point(20, 85) : Me.ListView1.MultiSelect = False : Me.ListView1.Name = "ListView1" : Me.ListView1.Size = New System.Drawing.Size(555, 250) : Me.ListView1.UseCompatibleStateImageBehavior = False : Me.ListView1.View = System.Windows.Forms.View.Details
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!) : Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font : Me.ClientSize = New System.Drawing.Size(584, 341) : Me.Controls.Add(Me.Panel1) : Me.Name = "FormCariProduk" : Me.Text = "Cari Data Produk"
        Me.Panel1.ResumeLayout(False) : Me.Panel1.PerformLayout() : Me.ResumeLayout(False)
    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtCariData As System.Windows.Forms.TextBox
    Friend WithEvents btnCariData As System.Windows.Forms.Button
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
End Class
