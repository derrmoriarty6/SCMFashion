Imports MySql.Data.MySqlClient
Public Class FormCariKategori
    Private Sub caridatakategori()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblkategori WHERE kd_kategori like '%" & Trim(txtCariData.Text) & "%' or nm_kategori like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData) : ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub
    Private Sub AmbilDataDariListview()
        With ListView1.SelectedItems
            Try
                FormTransaksi.txtKdKategori.Text = .Item(0).SubItems(0).Text
                FormTransaksi.txtNamaKategori.Text = .Item(0).SubItems(1).Text
            Catch ex As Exception
            End Try
        End With
    End Sub
    Private Sub Posisilist()
        With ListView1.Columns
            .Add("Kode Kategori", 100) : .Add("Nama Kategori", 200) : .Add("Deskripsi", 250)
        End With
    End Sub
    Private Sub Isilist()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblkategori ORDER BY kd_kategori"
            daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData) : ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1)) : .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub
    Private Sub FormCariKategori_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksiKeDataBase() : Posisilist() : Isilist()
    End Sub
    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatakategori()
    End Sub
    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatakategori()
    End Sub
    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview() : Me.Close()
    End Sub
End Class
