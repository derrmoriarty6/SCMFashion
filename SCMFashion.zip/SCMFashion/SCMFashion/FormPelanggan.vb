Imports MySql.Data.MySqlClient
Public Class FormPelanggan
    Dim membership As String
    Dim a As MsgBoxResult

    Private Sub posisilist()
        With ListView1.Columns
            .Add("ID Pelanggan", 80)
            .Add("Nama", 120)
            .Add("Tempat Lahir", 100)
            .Add("Tanggal Lahir", 90)
            .Add("Usia", 100)
            .Add("Jenis Kelamin", 90)
            .Add("Membership", 80)
            .Add("Alamat", 150)
            .Add("Telp/HP", 100)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblpelanggan ORDER BY id_pelanggan"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub caridatapelanggan()
        Dim a As Integer
        Try
            query = "select * From tblpelanggan WHERE id_pelanggan like '%" & Trim(txtCariData.Text) & "%' or nama like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(7))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(8))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub AmbilDataDariListView()
        With ListView1.SelectedItems
            Try
                txtIdPelanggan.Text = .Item(0).SubItems(0).Text
                txtNama.Text = .Item(0).SubItems(1).Text
                txtTempatLahir.Text = .Item(0).SubItems(2).Text
                dtpTglLahir.Text = .Item(0).SubItems(3).Text
                txtUsia.Text = .Item(0).SubItems(4).Text
                Dim jenkel As String
                jenkel = .Item(0).SubItems(5).Text
                If jenkel = "Laki-Laki" Then
                    rdbLaki_Laki.Checked = True
                ElseIf jenkel = "Perempuan" Then
                    rdbPerempuan.Checked = True
                End If
                Dim membershipPlg As String
                membershipPlg = .Item(0).SubItems(6).Text
                If membershipPlg = "Gold" Then
                    cbGold.Checked = True
                ElseIf membershipPlg = "Silver" Then
                    cbSilver.Checked = True
                ElseIf membershipPlg = "Bronze" Then
                    cbBronze.Checked = True
                ElseIf membershipPlg = "Regular" Then
                    cbRegular.Checked = True
                ElseIf membershipPlg = "VIP" Then
                    cbVIP.Checked = True
                End If
                txtAlamat.Text = .Item(0).SubItems(7).Text
                txtTelp.Text = .Item(0).SubItems(8).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub FormPelanggan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call koneksiKeDataBase()
            Call posisilist()
            Call Isilist()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub dtpTglLahir_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpTglLahir.ValueChanged
        HitungUsia()
    End Sub

    Private Sub cbGold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbGold.CheckedChanged
        If cbGold.Checked = True Then
            cbSilver.Checked = False : cbBronze.Checked = False : cbRegular.Checked = False : cbVIP.Checked = False
            membership = "Gold"
        End If
    End Sub

    Private Sub cbSilver_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbSilver.CheckedChanged
        If cbSilver.Checked = True Then
            cbGold.Checked = False : cbBronze.Checked = False : cbRegular.Checked = False : cbVIP.Checked = False
            membership = "Silver"
        End If
    End Sub

    Private Sub cbBronze_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbBronze.CheckedChanged
        If cbBronze.Checked = True Then
            cbGold.Checked = False : cbSilver.Checked = False : cbRegular.Checked = False : cbVIP.Checked = False
            membership = "Bronze"
        End If
    End Sub

    Private Sub cbRegular_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbRegular.CheckedChanged
        If cbRegular.Checked = True Then
            cbGold.Checked = False : cbSilver.Checked = False : cbBronze.Checked = False : cbVIP.Checked = False
            membership = "Regular"
        End If
    End Sub

    Private Sub cbVIP_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbVIP.CheckedChanged
        If cbVIP.Checked = True Then
            cbGold.Checked = False : cbSilver.Checked = False : cbBronze.Checked = False : cbRegular.Checked = False
            membership = "VIP"
        End If
    End Sub

    Private Sub Bersih()
        txtIdPelanggan.Text = "" : txtNama.Text = "" : txtTempatLahir.Text = "" : txtUsia.Text = ""
        rdbLaki_Laki.Checked = False : rdbPerempuan.Checked = False
        cbGold.Checked = False : cbSilver.Checked = False : cbBronze.Checked = False : cbRegular.Checked = False : cbVIP.Checked = False
        txtAlamat.Text = "" : txtTelp.Text = ""
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Bersih() : Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            Dim jenkel As String
            If rdbLaki_Laki.Checked = True Then jenkel = "Laki-Laki" Else jenkel = "Perempuan"
            If txtIdPelanggan.Text = "" Or txtNama.Text = "" Or txtTempatLahir.Text = "" Or txtUsia.Text = "" Or txtAlamat.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtIdPelanggan.Focus()
            Else
                query = "Insert Into tblpelanggan Values('" & txtIdPelanggan.Text & "','" & txtNama.Text & "','" & txtTempatLahir.Text & "','" & Format(dtpTglLahir.Value, "yyyy/MM/dd") & "','" & txtUsia.Text & "','" & jenkel & "','" & membership & "','" & txtAlamat.Text & "','" & txtTelp.Text & "')"
                daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                MsgBox("Data berhasil disimpan!", MsgBoxStyle.Information, "SAVE")
                txtIdPelanggan.Focus() : Isilist() : Bersih()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error") : txtIdPelanggan.Focus()
        End Try
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            Dim jenkel As String
            If rdbLaki_Laki.Checked = True Then jenkel = "Laki-Laki" Else jenkel = "Perempuan"
            If txtIdPelanggan.Text = "" Or txtNama.Text = "" Then
                MsgBox("Silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtIdPelanggan.Focus()
            Else
                query = "UPDATE tblpelanggan SET nama='" & txtNama.Text & "',tempat_lahir='" & txtTempatLahir.Text & "',tgl_lahir='" & Format(dtpTglLahir.Value, "yyyy/MM/dd") & "',usia='" & txtUsia.Text & "',jenis_kelamin='" & jenkel & "',membership='" & membership & "',alamat='" & txtAlamat.Text & "',telp='" & txtTelp.Text & "' WHERE id_pelanggan='" & txtIdPelanggan.Text & "'"
                daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                Isilist() : Bersih() : txtIdPelanggan.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListView()
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            a = MsgBox("Benar data akan Di Delete ...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case a
                Case vbCancel : txtIdPelanggan.Focus() : Exit Sub
                Case vbOK
                    If txtIdPelanggan.Text = "" Then
                        MsgBox("Input ID Pelanggan yang akan di hapus", MsgBoxStyle.Critical, "Data Kosong")
                    Else
                        query = "Delete From tblpelanggan Where id_pelanggan='" & txtIdPelanggan.Text & "'"
                        daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                        Isilist() : Bersih()
                        MsgBox("Data berhasil di delete!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Hapus data")
        End Try
    End Sub

    Private Sub HitungUsia()
        Dim thn, bln As String
        thn = Year(Now) - Year(dtpTglLahir.Value)
        bln = Month(Now) - Month(dtpTglLahir.Value)
        txtUsia.Text = thn & " tahun, " & bln & " Bulan"
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatapelanggan()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatapelanggan()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
