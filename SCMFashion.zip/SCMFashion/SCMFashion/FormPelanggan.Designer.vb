<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormPelanggan
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtIdPelanggan = New System.Windows.Forms.TextBox()
        Me.txtNama = New System.Windows.Forms.TextBox()
        Me.txtTempatLahir = New System.Windows.Forms.TextBox()
        Me.dtpTglLahir = New System.Windows.Forms.DateTimePicker()
        Me.txtUsia = New System.Windows.Forms.TextBox()
        Me.rdbLaki_Laki = New System.Windows.Forms.RadioButton()
        Me.rdbPerempuan = New System.Windows.Forms.RadioButton()
        Me.cbGold = New System.Windows.Forms.CheckBox()
        Me.cbSilver = New System.Windows.Forms.CheckBox()
        Me.cbBronze = New System.Windows.Forms.CheckBox()
        Me.cbRegular = New System.Windows.Forms.CheckBox()
        Me.cbVIP = New System.Windows.Forms.CheckBox()
        Me.txtAlamat = New System.Windows.Forms.TextBox()
        Me.txtTelp = New System.Windows.Forms.TextBox()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnEdit = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtCariData = New System.Windows.Forms.TextBox()
        Me.btnCariData = New System.Windows.Forms.Button()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Panel1.Controls.Add(Me.ListView1)
        Me.Panel1.Controls.Add(Me.btnCariData)
        Me.Panel1.Controls.Add(Me.txtCariData)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.txtIdPelanggan)
        Me.Panel1.Controls.Add(Me.txtNama)
        Me.Panel1.Controls.Add(Me.txtTempatLahir)
        Me.Panel1.Controls.Add(Me.dtpTglLahir)
        Me.Panel1.Controls.Add(Me.txtUsia)
        Me.Panel1.Controls.Add(Me.rdbLaki_Laki)
        Me.Panel1.Controls.Add(Me.rdbPerempuan)
        Me.Panel1.Controls.Add(Me.cbGold)
        Me.Panel1.Controls.Add(Me.cbSilver)
        Me.Panel1.Controls.Add(Me.cbBronze)
        Me.Panel1.Controls.Add(Me.cbRegular)
        Me.Panel1.Controls.Add(Me.cbVIP)
        Me.Panel1.Controls.Add(Me.txtAlamat)
        Me.Panel1.Controls.Add(Me.txtTelp)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Controls.Add(Me.btnEdit)
        Me.Panel1.Controls.Add(Me.btnDelete)
        Me.Panel1.Controls.Add(Me.btnExit)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(900, 620)
        Me.Panel1.TabIndex = 0
        'Label1 - Title
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(220, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(350, 26)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "FORM INPUT DATA PELANGGAN"
        'Label2 - ID Pelanggan
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(31, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "ID Pelanggan"
        'Label3 - Nama
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(31, 90)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(110, 18)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Nama Pelanggan"
        'Label4 - Tempat Lahir
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(31, 120)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 18)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Tempat Lahir"
        'Label5 - Tgl Lahir
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(31, 150)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 18)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Tanggal Lahir"
        'Label6 - Usia
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(31, 180)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 18)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Usia"
        'Label7 - Jenis Kelamin
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(31, 210)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(102, 18)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Jenis Kelamin"
        'Label8 - Membership
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(31, 240)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(90, 18)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Membership"
        'Label9 - Alamat
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(31, 275)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 18)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Alamat"
        'Label10 - Telp
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(31, 305)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(90, 18)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Telepon/HP"
        'Label11 - Pencarian
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.Label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label11.Location = New System.Drawing.Point(27, 375)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 18)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Pencarian"
        'TextBoxes
        Me.txtIdPelanggan.Location = New System.Drawing.Point(170, 60) : Me.txtIdPelanggan.Name = "txtIdPelanggan" : Me.txtIdPelanggan.Size = New System.Drawing.Size(100, 20) : Me.txtIdPelanggan.TabIndex = 11
        Me.txtNama.Location = New System.Drawing.Point(170, 90) : Me.txtNama.Name = "txtNama" : Me.txtNama.Size = New System.Drawing.Size(200, 20) : Me.txtNama.TabIndex = 12
        Me.txtTempatLahir.Location = New System.Drawing.Point(170, 120) : Me.txtTempatLahir.Name = "txtTempatLahir" : Me.txtTempatLahir.Size = New System.Drawing.Size(150, 20) : Me.txtTempatLahir.TabIndex = 13
        Me.dtpTglLahir.Location = New System.Drawing.Point(170, 150) : Me.dtpTglLahir.Name = "dtpTglLahir" : Me.dtpTglLahir.Size = New System.Drawing.Size(200, 20) : Me.dtpTglLahir.TabIndex = 14
        Me.txtUsia.Location = New System.Drawing.Point(170, 180) : Me.txtUsia.Name = "txtUsia" : Me.txtUsia.Size = New System.Drawing.Size(150, 20) : Me.txtUsia.ReadOnly = True : Me.txtUsia.TabIndex = 15
        'RadioButtons - Jenis Kelamin
        Me.rdbLaki_Laki.AutoSize = True : Me.rdbLaki_Laki.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.rdbLaki_Laki.Location = New System.Drawing.Point(170, 210) : Me.rdbLaki_Laki.Name = "rdbLaki_Laki" : Me.rdbLaki_Laki.Size = New System.Drawing.Size(75, 17) : Me.rdbLaki_Laki.Text = "Laki-Laki" : Me.rdbLaki_Laki.TabIndex = 16
        Me.rdbPerempuan.AutoSize = True : Me.rdbPerempuan.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.rdbPerempuan.Location = New System.Drawing.Point(270, 210) : Me.rdbPerempuan.Name = "rdbPerempuan" : Me.rdbPerempuan.Size = New System.Drawing.Size(80, 17) : Me.rdbPerempuan.Text = "Perempuan" : Me.rdbPerempuan.TabIndex = 17
        'CheckBoxes - Membership
        Me.cbGold.AutoSize = True : Me.cbGold.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.cbGold.Location = New System.Drawing.Point(170, 240) : Me.cbGold.Name = "cbGold" : Me.cbGold.Size = New System.Drawing.Size(48, 17) : Me.cbGold.Text = "Gold" : Me.cbGold.TabIndex = 18
        Me.cbSilver.AutoSize = True : Me.cbSilver.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.cbSilver.Location = New System.Drawing.Point(230, 240) : Me.cbSilver.Name = "cbSilver" : Me.cbSilver.Size = New System.Drawing.Size(52, 17) : Me.cbSilver.Text = "Silver" : Me.cbSilver.TabIndex = 19
        Me.cbBronze.AutoSize = True : Me.cbBronze.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.cbBronze.Location = New System.Drawing.Point(295, 240) : Me.cbBronze.Name = "cbBronze" : Me.cbBronze.Size = New System.Drawing.Size(58, 17) : Me.cbBronze.Text = "Bronze" : Me.cbBronze.TabIndex = 20
        Me.cbRegular.AutoSize = True : Me.cbRegular.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.cbRegular.Location = New System.Drawing.Point(365, 240) : Me.cbRegular.Name = "cbRegular" : Me.cbRegular.Size = New System.Drawing.Size(63, 17) : Me.cbRegular.Text = "Regular" : Me.cbRegular.TabIndex = 21
        Me.cbVIP.AutoSize = True : Me.cbVIP.ForeColor = System.Drawing.SystemColors.ButtonHighlight : Me.cbVIP.Location = New System.Drawing.Point(440, 240) : Me.cbVIP.Name = "cbVIP" : Me.cbVIP.Size = New System.Drawing.Size(42, 17) : Me.cbVIP.Text = "VIP" : Me.cbVIP.TabIndex = 22
        'Alamat & Telp
        Me.txtAlamat.Location = New System.Drawing.Point(170, 275) : Me.txtAlamat.Name = "txtAlamat" : Me.txtAlamat.Size = New System.Drawing.Size(300, 20) : Me.txtAlamat.TabIndex = 23
        Me.txtTelp.Location = New System.Drawing.Point(170, 305) : Me.txtTelp.Name = "txtTelp" : Me.txtTelp.Size = New System.Drawing.Size(150, 20) : Me.txtTelp.TabIndex = 24
        'Buttons
        Me.btnRefresh.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnRefresh.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnRefresh.Location = New System.Drawing.Point(31, 340) : Me.btnRefresh.Name = "btnRefresh" : Me.btnRefresh.Size = New System.Drawing.Size(79, 29) : Me.btnRefresh.Text = "REFRESH" : Me.btnRefresh.UseVisualStyleBackColor = False : Me.btnRefresh.TabIndex = 25
        Me.btnSave.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnSave.Location = New System.Drawing.Point(114, 340) : Me.btnSave.Name = "btnSave" : Me.btnSave.Size = New System.Drawing.Size(79, 29) : Me.btnSave.Text = "SAVE" : Me.btnSave.UseVisualStyleBackColor = False : Me.btnSave.TabIndex = 26
        Me.btnEdit.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnEdit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnEdit.Location = New System.Drawing.Point(197, 340) : Me.btnEdit.Name = "btnEdit" : Me.btnEdit.Size = New System.Drawing.Size(79, 29) : Me.btnEdit.Text = "EDIT" : Me.btnEdit.UseVisualStyleBackColor = False : Me.btnEdit.TabIndex = 27
        Me.btnDelete.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnDelete.Location = New System.Drawing.Point(280, 340) : Me.btnDelete.Name = "btnDelete" : Me.btnDelete.Size = New System.Drawing.Size(79, 29) : Me.btnDelete.Text = "DELETE" : Me.btnDelete.UseVisualStyleBackColor = False : Me.btnDelete.TabIndex = 28
        Me.btnExit.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnExit.Location = New System.Drawing.Point(362, 340) : Me.btnExit.Name = "btnExit" : Me.btnExit.Size = New System.Drawing.Size(79, 29) : Me.btnExit.Text = "EXIT" : Me.btnExit.UseVisualStyleBackColor = False : Me.btnExit.TabIndex = 29
        'Search
        Me.txtCariData.Location = New System.Drawing.Point(102, 375) : Me.txtCariData.Name = "txtCariData" : Me.txtCariData.Size = New System.Drawing.Size(600, 20) : Me.txtCariData.TabIndex = 30
        Me.btnCariData.BackColor = System.Drawing.SystemColors.ButtonHighlight : Me.btnCariData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold) : Me.btnCariData.Location = New System.Drawing.Point(710, 375) : Me.btnCariData.Name = "btnCariData" : Me.btnCariData.Size = New System.Drawing.Size(92, 19) : Me.btnCariData.Text = "CARI DATA" : Me.btnCariData.UseVisualStyleBackColor = False : Me.btnCariData.TabIndex = 31
        'ListView
        Me.ListView1.FullRowSelect = True : Me.ListView1.GridLines = True : Me.ListView1.Location = New System.Drawing.Point(30, 400) : Me.ListView1.MultiSelect = False : Me.ListView1.Name = "ListView1" : Me.ListView1.Size = New System.Drawing.Size(840, 200) : Me.ListView1.UseCompatibleStateImageBehavior = False : Me.ListView1.View = System.Windows.Forms.View.Details : Me.ListView1.TabIndex = 32
        'FormPelanggan
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 611)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FormPelanggan"
        Me.Text = "Form Input Data Pelanggan"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtIdPelanggan As System.Windows.Forms.TextBox
    Friend WithEvents txtNama As System.Windows.Forms.TextBox
    Friend WithEvents txtTempatLahir As System.Windows.Forms.TextBox
    Friend WithEvents dtpTglLahir As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtUsia As System.Windows.Forms.TextBox
    Friend WithEvents rdbLaki_Laki As System.Windows.Forms.RadioButton
    Friend WithEvents rdbPerempuan As System.Windows.Forms.RadioButton
    Friend WithEvents cbGold As System.Windows.Forms.CheckBox
    Friend WithEvents cbSilver As System.Windows.Forms.CheckBox
    Friend WithEvents cbBronze As System.Windows.Forms.CheckBox
    Friend WithEvents cbRegular As System.Windows.Forms.CheckBox
    Friend WithEvents cbVIP As System.Windows.Forms.CheckBox
    Friend WithEvents txtAlamat As System.Windows.Forms.TextBox
    Friend WithEvents txtTelp As System.Windows.Forms.TextBox
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnEdit As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents txtCariData As System.Windows.Forms.TextBox
    Friend WithEvents btnCariData As System.Windows.Forms.Button
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
End Class
