Imports MySql.Data.MySqlClient
Public Class FormKategori

    Private Sub caridatakategori()
        Dim a As Integer
        Try
            query = "select * From tblkategori WHERE kd_kategori like '%" & Trim(txtCariData.Text) & "%' or nm_kategori like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblkategori ORDER BY kd_kategori"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub posisilist()
        With ListView1.Columns
            .Add("Kode Kategori", 100)
            .Add("Nama Kategori", 200)
            .Add("Deskripsi", 250)
        End With
    End Sub

    Private Sub Bersih()
        txtKdKategori.Text = "" : txtNamaKategori.Text = "" : txtDeskripsi.Text = ""
    End Sub

    Private Sub FormKategori_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksiKeDataBase() : posisilist() : Isilist()
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Bersih() : Isilist()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKdKategori.Text = "" Or txtNamaKategori.Text = "" Or txtDeskripsi.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKdKategori.Focus()
            Else
                query = "Insert Into tblkategori Values('" & txtKdKategori.Text & "','" & txtNamaKategori.Text & "','" & txtDeskripsi.Text & "')"
                daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                MsgBox("Data berhasil disimpan!", MsgBoxStyle.Information, "SAVE")
                txtKdKategori.Focus() : Isilist() : Bersih()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error") : txtKdKategori.Focus()
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListView()
    End Sub

    Private Sub AmbilDataDariListView()
        With ListView1.SelectedItems
            Try
                txtKdKategori.Text = .Item(0).SubItems(0).Text
                txtNamaKategori.Text = .Item(0).SubItems(1).Text
                txtDeskripsi.Text = .Item(0).SubItems(2).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If txtKdKategori.Text = "" Or txtNamaKategori.Text = "" Or txtDeskripsi.Text = "" Then
                MsgBox("Silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "Pesan Data Kosong")
                txtKdKategori.Focus()
            Else
                query = "UPDATE tblkategori SET nm_kategori='" & txtNamaKategori.Text & "',deskripsi='" & txtDeskripsi.Text & "' WHERE kd_kategori='" & txtKdKategori.Text & "' "
                daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                Isilist() : Bersih() : txtKdKategori.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            Dim A As String
            A = MsgBox("Benar data akan di delete...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case A
                Case vbCancel : txtKdKategori.Focus() : Exit Sub
                Case vbOK
                    If txtKdKategori.Text = "" Then
                        MsgBox("Input Kode Kategori Yang Akan Di Hapus", MsgBoxStyle.Critical, "Data Kosong")
                        txtKdKategori.Focus()
                    Else
                        query = "DELETE from tblkategori WHERE kd_kategori='" & txtKdKategori.Text & "'"
                        daData = New MySqlDataAdapter(query, conn) : dsData = New DataSet : daData.Fill(dsData)
                        Isilist() : Bersih()
                        MsgBox("Data Berhasil Di Delete", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Hapus data")
        End Try
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridatakategori()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridatakategori()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
